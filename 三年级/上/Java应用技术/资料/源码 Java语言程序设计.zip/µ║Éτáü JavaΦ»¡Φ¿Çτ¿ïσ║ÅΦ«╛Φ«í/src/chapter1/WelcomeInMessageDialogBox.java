package chapter1;

/** This application program displays Welcome to Java!
 *  in a message dialog box. 
 */
import javax.swing.JOptionPane;

public class WelcomeInMessageDialogBox { 
  public static void main(String[] args) { 
    // Display Welcome to Java! in a message dialog box
    JOptionPane.showMessageDialog(null, "Welcome to Java!");
  }
}
